<?php

return array(

    'facebook'  => array(

        'app_id' => '437182660058525',
        'app_secret' => 'a6a7dc1d4c9eba0f85fe4ca951f89a98',
        'call_back'  => 'https://jiolink.com/loginwith/facebook'
        
        ),
    
    'google'  => array(

        'clientId'      => '590447752447-go0qsrlcj8alsisd6q0a22eolrl2m7a3.apps.googleusercontent.com',
        'clientSecret'  => 'PrWjSRh-Ua6Nqc_vaO4hzi7s',
        'redirectUri'   => 'https://jiolink.com/loginwith/google',
        'hostedDomain'  => 'https://jiolink.com/'
        
        )
);
