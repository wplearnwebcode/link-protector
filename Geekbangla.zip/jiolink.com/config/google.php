<?php

return array(
    'key' => '6LfrkFcUAAAAAH2kUDUF06I6jmsc1dhgNWGfkLd6',
    'secret' => '6LfrkFcUAAAAAOQ7pYHmsGmxswOY1TP2rLugnK-_'
    );
