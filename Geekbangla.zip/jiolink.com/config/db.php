<?php

return array(
    'hostname' => (System\Config::app('env') == 'dev')? '127.0.0.1' : 'localhost',
    'username' => (System\Config::app('env') == 'dev')? 'root' : 'vipsbrpd_jio',
    'password' => (System\Config::app('env') == 'dev')? 'rock' : 'Lxbo{uIn&V=V',
    'database' => (System\Config::app('env') == 'dev')? 'sudo' : 'vipsbrpd_jio',
    'charset' => 'utf8'
);