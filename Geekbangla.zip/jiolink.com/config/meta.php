<?php

return array(

    'home' => array(

            'title' => 'JioLink - Multiple Link Protector & Earn Money',
            'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines also earn money from them'
        ),

    'protected' => array(

            'title' => 'Protected Link - JioLink',
            'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
        ),

    'contact' => array(

            'title' => 'Contact Us - JioLink',
            'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
        ),

    'edit' => array( // edit links

            'title' => 'Edit Links - JioLink',
            'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
        ),

    'faqs' => array(

            'title' => 'FAQS - JioLink',
            'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
        ),

    'forget' => array(

            'title' => 'Forget Password - JioLink',
            'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
        ),

    'login' => array(

            'title' => 'Login - JioLink',
            'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
        ),

    'manage' => array(

            'title' => 'Manage Records - JioLink',
            'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
        ),

    'money' => array(

            'title' => 'Earn Money via JioLink',
            'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
        ),

    'dmca' => array(

            'title' => 'DMCA - JioLink',
            'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
        ),

    'terms' => array(

        'title' => 'Terms - JioLink',
        'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
    ),

    'privacy' => array(

        'title' => 'Privacy - JioLink',
        'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
    ),

    'payment' => array(

        'title' => 'Payment - JioLink',
        'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
    ),

    'register' => array(

        'title' => 'Register - JioLink',
        'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
    ),

    'remove' => array( // remove links

        'title' => 'Remove - JioLink',
        'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
    ),

    'reset' => array( // set new password

        'title' => 'Reset Password - JioLink',
        'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
    ), 

    'user' => array(

        'title' => 'User Settings - JioLink',
        'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
    ),         

    'view' => array(

        'title' => 'View Links - JioLink',
        'desc'  => 'JioLink is a free service offering link protection to avoid any links being indexed by spiders and eventually being listed on search engines.'
    ), 

    );