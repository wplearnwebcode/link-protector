<?php

return array(
    'timezone' => 'Asia/Calcutta',
    'language' => 'en_GB',
    'encoding' => 'UTF-8',
    'env'      => 'live',
    'domain'   => 'jiolink.com', 
    'scheme'   => 'https',
    'css-ver'  => '1',
    'js-ver'   => '2',   
    'email'    => 'onlinejiolink@gmail.com'//'extradesimovies@gmail.com', 
);
