<?php

namespace System;

class Check {

    /**
     * check if requst is post or get
     * @param  POST|GET 
     * @return boolean
     */
    public static function type($name){
        return $_SERVER['REQUEST_METHOD'] === strtoupper($name);
    }   

    /**
     * Check for post args
     * @param array variables
     * @return boolean
     */
    public static function post(){

        $args = func_get_args();

        foreach ($args as $k) {
            
            if(empty($_POST[$k]))
                return false;
        }

        return true;
    }

    /**
     * Check for get args
     * @param array variables
     * @return boolean
     */
    public static function get(){

        $args = func_get_args();

        foreach ($args as $k) {
            
            if(empty($_GET[$k]))
                return false;
        }

        return true;
    }

}