<?php

namespace System;

class Session{

    /**
     * Start Session
     * @return void();
     */
    public static function start(){
         session_start();
    }

    /**
     * Check if session exist
     * @param  string name
     * @return boolean;
     */
    public static function exists($name){

        return (isset($_SESSION[$name])) ? true : false;    
    }

    /**
     * Insert data in session
     * @param  mixed $name  the name of session
     * @param  mixed $value its value
     * @return boolean;
     */
    public static function put($name, $value){

        return $_SESSION[$name] = $value;   
    }

    /**
     * Delete item from session
     * @param  just name of session
     * @return void
     */
    public static function delete($name){

        if(self::exists($name)){

            unset($_SESSION[$name]);
        }   
    }

    /**
     * Get item from session array
     * @param  string name of session
     * @return string session value
     */
    public static function get($name){

        return $_SESSION[$name];    
    }

    /**
     * Flashing session message just for one
     * @param  string $name  name of session
     * @param  string $string the data you want to show
     * @return void;
     */
    public static function flash($name, $string = ''){

        if(self::exists($name)){

            $session = self::get($name);

            self::delete($name);

            return $session;

        }else{

            self::put($name, $string);
        }   
    }

    /**
     * Simple modification of flash with just text
     * @param  string text
     * @return void();
     */
    public static function notify($text){
        self::flash('notifyThis', $text);
    }

}