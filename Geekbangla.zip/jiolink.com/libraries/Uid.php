<?php

namespace System;

class Uid{

    public static function generate($len = 10, $table = 'uid'){

     $db = DB::getInstance();

     while(1){

        $uid = self::createUid($len);

        $query = "SELECT id FROM links WHERE `{$table}` = ?";

        if(!$db->query($query, [$uid])->count()){
            
            break;
          }

       }

       return $uid;

    }

    public static function createUid($len){

        $base = 'ABCDEFGHKLMNOPQRSTWXYZabcdefghjkmnpqrstwxyz0123456789';

        $max = strlen($base)-1;

        $activatecode='';

        mt_srand((double)microtime()*1000000);

        while (strlen($activatecode)< $len)

        $activatecode.=$base{mt_rand(0,$max)};

        return $activatecode;

    }

}