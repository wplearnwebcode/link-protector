<?php

namespace System;

class Cookie{

   /**
    * checks if cookie exists
    * @param  string name
    * @return boolean
    */
    public static function exists($name){
        return (isset($_COOKIE[$name])) ? true : false;
    }

    /**
     * Get cookie value
     * @param  string name
     * @return string value
     */
    public static function get($name){
        return $_COOKIE[$name];
    }

    /**
     * Insert value in cookie
     * @param  string name of cookie
     * @param  mixed value of cookie
     * @param  integer expired on (default = 864000)
     * @return boolean
     */
    public static function put($name, $value , $expiry = 864000){

        if(setcookie($name, $value, time() + $expiry, '/')) return true;

        return false;
    }

    /**
     * Delete cookie from server
     * @param  string cookie name
     * @return void();
     */
    public static function delete($name){
        self::put($name, null, time() - 1);
    }

}