<?php

namespace System;

class Hash
{
    /**
     * Hashing password with new php API
     * @param  string password
     * @return string hash
     */
    public static function make($value, $rounds = 12)
    {
        return password_hash($value, PASSWORD_BCRYPT, array('cost' => $rounds));
    }

    /**
     * Verifying HASH password with new php API
     * @param  string password
     * @return boolean
     */
    public static function check($value, $hash)
    {
        return password_verify($value, $hash);
    }
}