<?php

namespace System;

class Module{

   /**
    * Basically include module easy way 
    * @param   string $method 
    * @param  array $arguments
    */
   public static function __callStatic($method, $arguments)
    {   
        $path = PATH.'module/'.$arguments[0].EXT;

        if(!file_exists($path)){
            throw new \Exception("{$method}/{$arguments[0]} module not found !");
            return;
        }
        
        return $path;
    }

}