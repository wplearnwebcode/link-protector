<?php

namespace System;

class View{

    /**
     * The current path to view file
     * @var string
     */
    public $_apath, $_rPath; // absolute and relative paths

    /**
     * Create a instance or the View class
     * @param string
     * @param array
     */
    public function __construct($path, $params = null) {

        $this->_rPath = $path;
        $this->_params = $params;
        $this->_apath = PATH . 'views/' . $path . EXT;
    }

    /**
     * Render the view
     * @return string
     */
    public function render(){

        ob_start(); // bufefering start
        require $this->_apath;
        $data = ob_get_clean(); // end buffering and clean
        
        return $data;
    }

    public function xinclude($path){
        require PATH.'views/'.$path.EXT;
    }

}