<?php

namespace System;

class Mail{

    private $_mailer;

    /**
     * Making instance of PHPMailer 
     * Doing basic settings
     */
    public function __construct(){
        $this->_mailer = new \PHPMailer;
    }


    public function send($subject, $body, $altBody, $recepient){

        //From email address and name
        $this->_mailer->From = "admin@9xlinks.net"; // 5fX0i}.gC;]H
        $this->_mailer->FromName = "Admin 9xlinks";
        $this->_mailer->addAddress($recepient);
        $this->_mailer->addReplyTo(Config::app('email'), "Reply");

        $this->_mailer->isHTML(true);
        $this->_mailer->Subject = $subject;
        $this->_mailer->Body = $body;
        $this->_mailer->AltBody = $altBody;

        // basicall create the message & send it
        $this->_mailer->send();
    }

}