<?php
use System\Response;
use System\Check;

$uid = $params['uid'];

// just delete it anywayw
$dbQuery = "DELETE FROM links WHERE delete_uid = ?";
$dbo->query($dbQuery, [$uid]);

// View Class Instance
$view = new System\View('remove');

// include common
include('common.php');

$view->title = System\Config::meta('remove')['title'];
$view->meta_desc = System\Config::meta('remove')['desc'];
$view->canonicalUrl = System\Uri::full('/remove/'.$uid);
$view->noIndex = true;

$view->pageType = 'remove';
$data = $view->render();

echo $data;