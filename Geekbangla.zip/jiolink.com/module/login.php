<?php
use System\Check;
use System\Session;
use System\Response;

if(Check::type('post')){

  if(!Check::post('email', 'password')){
    Session::flash('error', 'All fields are required');
    Response::redirect('login');
  }

  $email = escapeText($_POST['email']);
  $password = escapeText($_POST['password']);

  /* trying to login */
    if(!$usero->login($email, $password)){
        Session::flash('error', 'Username/password combination is incorrect');
        Response::redirect('login');
    }

    Response::redirect('/');
}

// View Class Instance
$view = new System\View('login');

// include common
include('common.php');

$view->title = System\Config::meta('login')['title'];
$view->meta_desc = System\Config::meta('login')['desc'];
$view->canonicalUrl = System\Uri::full('/login');

$view->pageType = 'login';
$data = $view->render();

echo $data;