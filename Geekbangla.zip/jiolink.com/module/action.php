<?php

use System\Check;

// if no method
if(!Check::post('type')) die();

$type = $_POST['type'];

// if ajax for status change
if($type == 'status'):

    include 'actions/status.php';

elseif($type == 'delete'):

     include 'actions/delete.php';

endif;


