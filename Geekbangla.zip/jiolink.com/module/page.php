<?php

$slug = $params['slug'];

if(!in_array($slug, ['privacy', 'terms', 'dmca']))
    System\Response::error(404);

// View Class Instance
$view = new System\View('page');

// include common
include('common.php');

$view->title = System\Config::meta($slug)['title'];
$view->meta_desc = System\Config::meta($slug)['desc'];
$view->canonicalUrl = System\Uri::full('/page/'.$slug);

$view->pageSlug = $slug;
$view->pageType = 'page';
$data = $view->render();

echo $data;