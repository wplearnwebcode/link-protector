<?php

$view->isLoggedIn = $usero->isLoggedIn();
$view->isAdmin = $usero->isAdmin();