<?php
use System\Response;
use System\Check;
use System\Session;

if(Check::type('post')){

    $postData  = $_POST['data'];

    if(!$postData['email'] 
        || !$postData['name'] 
            || !$postData['topic']
                || !$postData['message']){

        Session::flash('error', 'All fields are required');
        Response::redirect('contact');
    }

    foreach ($postData as $key => $value) {
       $postData[$key] = escapeText($value, ENT_NOQUOTES);
    }

    /**
     * Send mail here
     */
    $mailer = new System\Mail();

    $textmessage = 
"\r\n Name - ".$postData['name']."\r\n
Email - ".$postData['email']."\r\n
Topic - ".$postData['topic']."\r\n
Message - ".$postData['message']."\r\n";

    $htmlmessage = 
"<br/> Name - ".$postData['name']."<br/><br/>
Email - ".$postData['email']."<br/><br/>
Topic - ".$postData['topic']."<br/><br/>
Message - ".$postData['message']."<br/><br/>";

   $mailer->send('Contact Message On 9xlinks', $htmlmessage, $textmessage, System\Config::app('email'));

   Session::flash('success', 'Message sent successfully.');
   Response::redirect('contact');
}

// View Class Instance
$view = new System\View('contact');

// include common
include('common.php');

$view->title = System\Config::meta('contact')['title'];
$view->meta_desc = System\Config::meta('contact')['desc'];
$view->canonicalUrl = System\Uri::full('/contact');

$view->userData = $usero->data();
$view->pageType = 'contact';
$data = $view->render();

echo $data;