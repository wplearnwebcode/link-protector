<?php
use System\Check;
use System\Response;

$postData = $_POST['data'];

// priority
if($_FILES['txt']['tmp_name'])
    $content = file_get_contents($_FILES['txt']['tmp_name']);
elseif($postData['links'])
    $content = $postData['links'];
elseif($postData['remote'])
    $content = file_get_contents($postData['remote']);
else {
    System\Session::flash('error', 'Please provide valid links.');
    Response::redirect('/');
}

// matching urls
if(!$content = matchUrls($content)){
    System\Session::flash('error', 'Please provide valid links.');
    Response::redirect('/');
}

$content = serialize($content);

// View Class Instance
$view = new System\View('protected');

// include common
include('common.php');

$uid = System\Uid::generate();

$delete_uid = System\Uid::generate(10, 'delete_uid');

$link_fields = array(
    'uid' => $uid,
    'status' => 'active',
    'content' => $content,
    'delete_uid' => $delete_uid
    );

// if logged in store user id
if($usero->isLoggedIn())
    $link_fields['user_id'] = $usero->data()->id;

// if logged in store user id
if($postData['password'])
    $link_fields['password'] = System\Hash::make($postData['password']);

// if logged in store user id
if($postData['title'])
    $link_fields['title'] = escapeText($postData['title'], ENT_NOQUOTES);

// insert in db
$dbo->insert('links', $link_fields);

$view->uid = $uid;
$view->delete_uid = $delete_uid;

$view->title = System\Config::meta('protected')['title'];
$view->meta_desc = System\Config::meta('protected')['desc'];
$view->canonicalUrl = System\Uri::full('/protected');
$view->noIndex = true;

$view->pageType = 'protected';
$data = $view->render();

echo $data;