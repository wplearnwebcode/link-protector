<?php

// View Class Instance
$view = new System\View('money');

// include common
include('common.php');


$payoutRates = [];

$rates = $dbo->query("SELECT * FROM payment_rates")->results();

foreach ($rates as $k)
   $payoutRates[$k->group] = $k->rate;


$view->title = System\Config::meta('money')['title'];
$view->meta_desc = System\Config::meta('money')['desc'];
$view->canonicalUrl = System\Uri::full('/money');

$view->rates = $payoutRates;
$view->pageType = 'money';
$data = $view->render();

echo $data;