<?php

use System\Response;

// if is logged in then clear cache
if($usero->isLoggedIn()) $usero->logout();

// redirect anyway
Response::redirect('/');