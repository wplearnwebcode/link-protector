<?php
use System\Response;
use System\Check;
use System\Session;


if(Check::type('post')){

    if(!Check::post('email')){
        Session::flash('error', 'Email address required');
        Response::redirect('forget');
    }

    //validate captcha
       $recaptcha = new \ReCaptcha\ReCaptcha(System\Config::google('secret'));
       $resp = $recaptcha->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);

    if(!$resp->isSuccess()){
         System\Session::flash('error', 'Captcha verification required');
         System\Response::redirect('forget');
    }

    $email = escapeText($_POST['email']);
    $usero->forget($email);

    Session::flash('success', 'Check your mail. Your password reset email should arrive shortly.');
    Response::redirect('forget');
}

// View Class Instance
$view = new System\View('forget');

// include common
include('common.php');

$view->title = System\Config::meta('forget')['title'];
$view->meta_desc = System\Config::meta('forget')['desc'];
$view->canonicalUrl = System\Uri::full('/forget');

$view->pageType = 'forget';
$data = $view->render();

echo $data;