<?php
use System\Response;
use System\Check;

$uid = $params['uid'];

/**
 * check for valid link and get data anyway
 */
$checkQuery = "SELECT content FROM links WHERE status = 'active' AND uid = ? LIMIT 1";

$checkDbo = $dbo->query($checkQuery, [$uid]);

if(!$checkDbo->count()) Response::error(404);

$link_data = $checkDbo->first()->content;

$link_data = unserialize($link_data);

$content = '';

foreach ($link_data as $k) {
    
    $content .= $k."\r\n";
}

header('Content-disposition: attachment; filename='.$uid.'.txt');
header('Content-type: text/plain');

echo $content;