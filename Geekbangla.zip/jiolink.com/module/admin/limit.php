<?php
use System\Response;
use System\Check;
use System\Session;

$methods = $dbo->query("SELECT * FROM payment")->results();

if(Check::type('post')){

    // if limit
    if(isset($_POST['limit'])){

        $limit_data = $_POST['limit'];

        if($limit_data['name'] && $limit_data['minimum']){
            $dbo->update('payment', $limit_data['name'], ['minimum' => $limit_data['minimum']]);
            Session::flash('success', 'Limit changed successfully');
        }

    }elseif(isset($_POST['add'])){

        $add_data = $_POST['add'];

        if($add_data['name'] && $add_data['minimum']){
            $dbo->insert('payment', ['name' => strtolower($add_data['name']), 'minimum' => $add_data['minimum']]);
            Session::flash('success', 'Method added successfully');
        }

    }elseif(isset($_POST['remove'])){

        $remove_data = $_POST['remove'];

        if($remove_data['name']){
            $dbo->delete('payment', ['id', '=', $remove_data['name']]);
            Session::flash('success', 'Method removed successfully');
        }
    }

    Response::redirect('admin/limit');
}

// View Class Instance
$view = new System\View('admin/limit');

// include common
include(PATH.'/module/common.php');

$view->methods = $methods;

$view->title = 'Manage Methods - 9xlinks';
$view->meta_desc = '';
$view->canonicalUrl = System\Uri::full('/admin/limit');
$view->noIndex = true;

$view->pageType = 'admin/limit';
$data = $view->render();

echo $data;