<?php
use System\Response;
use System\Check;
use System\Session;

if(Check::type('post')){

    if(Check::post('rate', 'group')){

        $rate = $_POST['rate'];
        $group = $_POST['group'];

        $dbo->update('payment_rates', $group, ['rate' => $rate]);

        Session::flash('success', 'payment rate succesfully changed!');

        Response::redirect('/admin/rates');
    }

}

// View Class Instance
$view = new System\View('admin/rates');

// include common
include(PATH.'/module/common.php');

$payoutRates = [];

$rates = $dbo->query("SELECT * FROM payment_rates")->results();

foreach ($rates as $k)
   $payoutRates[$k->group] = $k->rate;

$view->rates = $payoutRates;


$view->title = 'Set Payment Rates - 9xlinks';
$view->meta_desc = '';
$view->canonicalUrl = System\Uri::full('/admin/rates');
$view->noIndex = true;

$view->pageType = 'admin/rates';
$data = $view->render();

echo $data;