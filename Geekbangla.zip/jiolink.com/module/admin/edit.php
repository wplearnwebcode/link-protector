<?php
use System\Response;
use System\Check;
use System\Session;

$payment_id = $params['id'];

$query = "SELECT users.username,
	users.payment_value,
        payment_history.amount,
        payment_history.created,
        payment_history.status,
        payment.name as payment_name
    FROM payment_history
    JOIN users
    	ON payment_history.user_id = users.id
    JOIN payment
    	ON payment.id = users.payment_id
    WHERE payment_history.id = ?";

// check if valid payment query
$payment_query  = $dbo->query($query, [$payment_id]);

if(!$payment_query->count())
    Response::error(404);

if(Check::type('post') && Check::post('status')){

    $status = 'pending';

    if($_POST['status'] == 'completed')
            $status = 'completed';

    $dbo->update('payment_history', $payment_id, ['status' => $status]);

    Session::flash('success', 'Payment status successfully changed.');

    Response::redirect('/admin/edit/'.$payment_id);

}

// View Class Instance
$view = new System\View('admin/edit');

// include common
include(PATH.'/module/common.php');

$view->payment_data = $payment_query->first();

$view->title = 'Edit Payment Status - 9xlinks';
$view->meta_desc = '';
$view->canonicalUrl = System\Uri::full('/admin/edit/'.$payment_id);
$view->noIndex = true;

$view->pageType = 'admin/edit';
$data = $view->render();

echo $data;