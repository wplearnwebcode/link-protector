<?php

// View Class Instance
$view = new System\View('faqs');

// include common
include('common.php');

$view->title = System\Config::meta('faqs')['title'];
$view->meta_desc = System\Config::meta('faqs')['desc'];
$view->canonicalUrl = System\Uri::full('/faqs');

$view->pageType = 'faqs';
$data = $view->render();

echo $data;