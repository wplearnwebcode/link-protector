<?php
use System\Check;
use System\Response;
use System\Session;


// View Class Instance
$view = new System\View('payment');

// include common
include('common.php');

$user_id = $usero->data()->id;

if($usero->isAdmin() && isset($params['user']))
    $user_id = $params['user'];

// total payment
$total = 0;
$payment_history = $dbo->query("SELECT * FROM payment_history WHERE user_id = ? ORDER BY id DESC", [$user_id])->results();
foreach ($payment_history as $k) {
    if($k->status == 'pending')
        continue;
    $total += $k->amount;
}

/**
 * total balance minus total payout
 */
$current_balance = $dbo->query("SELECT SUM(revenue) as sum FROM links where user_id = ?", [$user_id])->first()->sum;
$current_balance = roundMoney($current_balance - $total);


/*
 *pending payment
 *if pending just remove the current one
 */ 
$pending = '-';
$pendingQuery = $dbo->query("SELECT amount FROM payment_history WHERE user_id = ? AND status = 'pending'", [$user_id]);
if($pendingQuery->count()){
    $pending = roundMoney($pendingQuery->first()->amount);
    $current_balance = roundMoney($current_balance - $pending);
    $pending = '$'.$pending;
}


// if post data
if(Check::type('post') && !$usero->isAdmin()){

 if(!Check::post('amount')){
    Session::flash('error', 'Please enter a valid amount.');
    Response::redirect('payment');
 }  

 /**
  * check if user has any pending payment
  */
 $pending_check = $dbo->query("SELECT id FROM payment_history WHERE user_id = ? AND status = 'pending'", [$user_id]);
 if($pending_check->count()){
    Session::flash('error', 'A payment request is already in process.');
    Response::redirect('payment');
 }

 $requested_amount = escapeText($_POST['amount']);
 $requested_amount = roundMoney($requested_amount);

 if(!$usero->data()->payment_id){
    Session::flash('error', 'Add a payment method via settings.');
    Response::redirect('payment');
 }

 // get user limit
 $payment_data  = $dbo->query('SELECT minimum, name FROM payment WHERE id = ?', [$usero->data()->payment_id])->first();
 $payment_minimum = $payment_data->minimum;
 $payment_name = $payment_data->name;

 if($requested_amount < $payment_minimum){
    Session::flash('error', "Minimum for {$payment_name} is {$payment_minimum}.");
    Response::redirect('payment');
 }

 if($requested_amount > $current_balance){
    Session::flash('error', "Sorry you don't have that much balance.");
    Response::redirect('payment');
 }

 /**
  * now everything is okay just add it queue
  */
 $payment_fields = array(
     'user_id' => $user_id,
     'status' => 'pending',
     'amount' => $requested_amount
    );

 $dbo->insert('payment_history', $payment_fields);

 Session::flash('success', "You'll recieve your payment shortly.");
 Response::redirect('payment'); 

}

// pass vars
$view->pending_amount = $pending;
$view->total_payout = roundMoney($total);
$view->current_balance = $current_balance;
$view->payment_history = array_slice($payment_history, 0, 5);

$view->title = System\Config::meta('payment')['title'];
$view->meta_desc = System\Config::meta('payment')['desc'];
$view->canonicalUrl = System\Uri::full('/payment');
$view->noIndex = true;

$view->pageType = 'payment';
$data = $view->render();

echo $data;