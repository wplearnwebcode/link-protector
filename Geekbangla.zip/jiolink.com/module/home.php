<?php

// View Class Instance
$view = new System\View('home');

// include common
include('common.php');

$view->title = System\Config::meta('home')['title'];
$view->meta_desc = System\Config::meta('home')['desc'];
$view->canonicalUrl = System\Uri::full('/');

$view->pageType = 'home';
$data = $view->render();

echo $data;