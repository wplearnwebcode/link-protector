<?php
use System\Response;

$paramType = $params['type'];

if(!in_array($paramType, ['facebook', 'google'])) Response::error(404);

if($paramType == 'facebook'):

// include facebook
include 'social/facebook.php';

elseif($paramType == 'google'):

// include google
include 'social/google.php';

endif;