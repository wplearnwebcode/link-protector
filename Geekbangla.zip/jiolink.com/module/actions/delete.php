<?php

use System\Points;

$table = $_POST['table']; 
$records = explode(',' , $_POST['records']);

foreach ($records as $k) {

 // link with revenue logic
 if($table == 'links'){

  if(!$usero->isAdmin()){  
  $revenue_query = $dbo->query("SELECT revenue FROM links WHERE id = ? AND user_id = ?", [$k, $usero->data()->id]);
    }else{
        $revenue_query = $dbo->query("SELECT revenue FROM links WHERE id = ?", [$k]);
    }

  if(!$revenue_query->count()) continue;

  $revenue = $revenue_query->first()->revenue;

  if($revenue != 0){
    System\Session::flash('error', ucwords($table).' with revenue cant be deleted just disable them!');
    continue;
  }

 }

  // delete it in the end
 $dbo->delete($table, array( 'id', '=', $k));

}

if(!System\Session::exists('error'))
        System\Session::flash('success', ucwords($table).' just got deleted!');

die('success!!'); 