<?php

$method = $_POST['method'];
$table = $_POST['table'];
$records = $_POST['records'];

/**
 * Check if valid user
 */
if(!$usero->isAdmin()){
    $valid_check = $dbo->query("SELECT id FROM links WHERE id = ? AND user_id = ?", [$records, $usero->data()->id]);
    if(!$valid_check->count()) die('invalid!!');
}

$dbo->update($table, $records, array( 'status' => $method));

die('success!!');