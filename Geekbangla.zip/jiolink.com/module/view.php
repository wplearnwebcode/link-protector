<?php
use System\Response;
use System\Check;
use System\Cookie;

// View Class Instance
$view = new System\View('view');

$uid = $params['uid'];

// pre request
$requestType = 'get';

/**
 * check for valid link and get data anyway
 */
$checkQuery = "SELECT links.password, 
       links.uid,
       links.user_id,
       links.content, 
       links.title,
       links.is_adsense,
       links.created, 
       links.views,
       users.username
 FROM links
 LEFT JOIN users
 ON links.user_id = users.id
 WHERE links.status = 'active'
 AND links.uid = ?
 LIMIT 1";

$checkDbo = $dbo->query($checkQuery, [$uid]);

if(!$checkDbo->count()) Response::error(404);

$link_data = $checkDbo->first();
$isPassword = ($link_data->password)? true : false;

if(Check::type('post')){

 // if(!\Volnix\CSRF\CSRF::validate($_POST)) 
            //   System\Response::redirect('/');

 /* if(!$usero->isLoggedIn()):              
    //validate captcha
     $recaptcha = new \ReCaptcha\ReCaptcha(System\Config::google('secret'));
     $resp = $recaptcha->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);

     if(!$resp->isSuccess()){
       System\Session::flash('error', 'Captcha verification required');
       System\Response::redirect('view/'.$uid);
     }
  endif;*/

   // if passwor then match the decrypt key
   if($isPassword){

      if(!Check::post('password')){
        System\Session::flash('error', 'Decrypt key required');
        System\Response::redirect('view/'.$uid);
      }

      if(!System\Hash::check($_POST['password'], $link_data->password)){
        System\Session::flash('error', 'Decrypt key doesn\'t match');
        System\Response::redirect('view/'.$uid);
      }
   }

   /**
    * do page views and stuff here 
    */
   
   if($link_data->username && !$usero->isLoggedIn()){
     $revenueObj = new System\Revenue;
     $revenueObj->make($uid);
   }

   // if everything is correct
   $requestType = 'post';
}

// include common
include('common.php');


if(Cookie::exists('links')){

    $cookies = unserialize(Cookie::get('links'));

    if(isset($cookies[md5($uid)]))
         $requestType = 'post';

}

if(($usero->isLoggedIn() && $link_data->user_id == $usero->data()->id)
        ||$usero->isAdmin() 
          || ($requestType == 'get' && $usero->isLoggedIn() && !$isPassword)
	  || $link_data->user_id == 0){
    $requestType = 'post';
}


$view->requestType = $requestType;
$view->isPassword  = $isPassword;
$view->link_data = $link_data;


if($link_data->title)
    $view->title = ucwords($link_data->title);
else
  $view->title = System\Config::meta('view')['title'];

$view->meta_desc = System\Config::meta('view')['desc'];
$view->canonicalUrl = System\Uri::full('/view/'.$uid);
$view->noIndex = true;

$view->pageType = 'view';
$data = $view->render();

echo $data;