<?php $this->xinclude('partials/header'); ?>

    <div class="register-wrapper">
        <form method="post"  action="" class="form-horizontal" autocomplete="off"a>
            <h1 class="register-title">Login to your account</h1>

          <?php if(System\Session::exists('error')): ?>
            <div class="home-error-wrap">
              <div class="alert btn-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>*</strong> <?php echo System\Session::flash('error'); ?>
              </div>
            </div>
          <?php endif; ?>

            <div class="row">
                <div class="form-group">
                  <label class="control-label col-sm-2" for="username">Username / Email:</label>
                   <div class="col-sm-6">
                      <input type="text" name="email" class="form-control" id="username" placeholder="Enter username / email" required="">
                    </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">Password:</label>
                <div class="col-sm-6"> 
                  <input type="password" name="password" class="form-control" id="pwd" placeholder="Enter password" required>
                </div>
              </div>
              <div class="col-sm-3 col-sm-offset-1">
                <button type="submit" class="btn btn-default btn-block">Login</button>
              </div>
              <div class="col-sm-3">
                <a href="/forget" class="btn">Reset your password?</a>
              </div>
            </div>
        </form>

        <hr/>

        <div class="row">
            <div class="col-sm-3 col-sm-offset-1">
                <a href="/loginwith/facebook" class="btn social-facebook">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                    Login with facebook
                </a>
            </div>
            <div class="col-sm-3">
                 <a href="/loginwith/google" class="btn social-google">
                    <i class="fa fa-google-plus" aria-hidden="true"></i>
                    Login with google
                </a>
            </div>
        </div>

    </div>

<?php $this->xinclude('partials/footer'); ?>