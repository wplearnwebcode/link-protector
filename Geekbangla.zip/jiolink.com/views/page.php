<?php $this->xinclude('partials/header'); ?>
<div class="money-wrap">
<?php if($this->pageSlug == 'privacy'): ?>
    <h1 class="money-heading">
        Privacy Policy
    </h1>
<p>JioLink's policy is to respect and protect the privacy of our users. We at JioLink.Com respect your privacy. All information collected at JioLink.Com is kept confidential and will not be sold, resued, or rented in any way. We do not share your infromation with any 3rd parties.</p>
<strong>IP Addresses:</strong>
<p>IP addresses are logged by JioLink.Com to ensure account safety features availability, measuring usage and statistics.</p>
 
<strong>Email Addresses:</strong>
<p>We collect email addresses of users at the time of registration as means of contact and verification. JioLink.Com does not rent, sell, or share your email addresses with anyone.</p>
 
<strong>Your account username and password:</strong>
<p>Please note that it is your responsibility to keep the username and password confidential, so do not share it with anyone. If you use a public PC, make sure you log out prior to leaving JioLink.Com site. You are solely responsible for keeping your username/password inviolable.</p>
 
<strong>Certain Exceptional Disclosures:</strong>
<p>We may disclose your information if necessary to protect our legal rights or if the information relates to actual or threatened harmful conduct or potential threats to the physical safety of any person. The disclosure of personal information may be required by court or law enforcement officials.</p>
 
<strong>Use of Cookies:</strong>
<p>JioLink.Com uses cookies in order to track and analyze preferences of our users and, as a result, improve our site. A cookie is an encrypted number, generated when you visit any site that supports sessions. This cookie is saved permanently on your computer. This data does not contain any secure information (just an encrypted string). Additionally, we set a cookie when you log in to make further logging into our system a little easier. No other website can access any information about you from the cookies we may store on your local computer. We do not share cookies or any other type of information with any other companies. You can always choose not to receive a cookie file by enabling your web browser to refuse cookies or to prompt you before accepting a cookie.</p>
 
<strong>Third party cookies:</strong>
<p>In case of serving advertisements to this site, our third-party advertiser may place or recognize a unique cookie on your browser.</p>
 
<strong>External links:</strong>
<p>If any part of the JioLink.Com website links you to other websites, those websites do not operate under this Privacy Policy. We recommend you examine the privacy statements posted on those other websites to understand their procedures for collecting, using and disclosing personal information.</p>
 
<strong>Changes to Privacy Policy:</strong>
<p>We reserve the right, at any time and without notice, to add to, change, update, or modify this Privacy Policy. Any change, update, or modification will be effective immediately upon posting on the site. Please check this page periodically for changes.</p>
<?php elseif($this->pageSlug == 'terms'): ?>
    <h1 class="money-heading">
        Terms
    </h1>
<strong>General:</strong>
<p>JioLink.Com is a free service that helps users to protect links from inconvenient people or automated robots with security such as captcha and password. This JioLink.Com service agreement (the "Agreement") describes the terms and conditions on which JioLink.Com ("we") offer services to you ("User"). By using our services, User agrees to be bound by the following terms and conditions:<p>


<strong>Conditions for Use:</strong>
<p>Do not try to abuse or cheat our system. We reserve the right to delete and banned your account without any warning if we will be suspicious for abuse.</p>

<strong>(A) It is prohibited to upload content-</strong>
<p>Which violates the applicable Criminal Laws such as Child Pornography
Which infringe upon the copyright, patent or intellectual property rights.</p>

<strong>(B) The uses of the service-</strong>
<p>May not use the service to access or distribute illegal or immoral content.<br/>
May not use the service to incite or participate in criminal acts. Likewise, instructions for the committing of criminal acts may not be expressed or published in any form or manner.<br/>
May not disseminate content which is harassing, defamatory, obscene, racist, glorifying of violence, discriminatory, pornographic or threatening.<br/>
May not abuse the system resources.<br/>
Users must agree to comply with all laws which apply to their location, including copyright and trademark laws. Images, videos and files that violate copyrights or trademarks are not allowed. If someone has an infringement claim against you, we will remove that reported user and link from our site.</p>
 
<strong>Responsibility for user account information:</strong>
<p>The user holds full responsibility for keeping the account information safe and confidential (as well as authorized user's account information). The user is also entirely responsible for all the actions carried out via his/her account.</p>
 
<strong>Modifications to Terms of Service:</strong>
<p>JioLink.Com reserves the right to change any of these terms and services at any time.</p>
 
<strong>No Resale of the Service:</strong>
<p>Member's right to use the Service is personal to Member. Member agrees not to resell the Service without the express consent of JioLink.Com.</p>


<strong>We reserve the rights to take action:</strong>
<p>JioLink reserves the right to block and/or delete immediately any dubious files or those that include clear violations of law or are immoral.<br/>
JioLink.Com reserves the right to refuse any submitted content without giving cause.<br/>
JioLink does not tolerate illegal content and expressly states that all files with illegal content will be deleted immediately after that fact becomes known to JioLink and technical measures will be taken to prevent an attempt at protecting the content again.</p>


<strong>Backup Your Content:</strong>
<p>The user is responsible for the backing up (to his own computer or other devices) of the files (urls) that he stores or accesses on JioLink's servers. JioLink does not guarantee or warrant that any content that the user saves, stores or accesses through the service will not be subject to inadvertent damage or loss.</p>
<?php elseif($this->pageSlug == 'dmca'): ?>
    <h1 class="money-heading">
        Dmca Copyright
    </h1>
<strong>Digital Millennium Copyright Act (DMCA)</strong>
<br/><br/>
<p>JioLink.Com intends to fully comply with the Digital Millennium Copyright Act ("DMCA"), including the notice and "take down" Provisions, and to benefit from the safe harbors immunizing Indishare from liability to the fullest extent of the law. Indishare reserves the right to terminate the account of any Member who infringes upon the copyright rights of others upon receipt of proper notification by the copyright owner or the copyright owner's legal agent. 
Included below are the processes and procedures that Indishare will follow to resolve any claims of intellectual property violations.</p>
<br/>
<p>It’s against our policies/terms to post copyrighted material you don’t have authorization to use.
If anybody find any link on our site which violate our terms in any case than report us asap
<a href="../contact">CONTACT US</a></p>
<p>Email ID: <b style="color:red;"></b></p> 
<p>For more details go to here <a href="terms">Terms and Conditions</a></p>
<?php endif; ?>
</div>
<?php $this->xinclude('partials/footer'); ?>