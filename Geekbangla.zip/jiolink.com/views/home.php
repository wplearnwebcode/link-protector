<?php $this->xinclude('partials/header'); ?>

<div class="home-wrapper">

<ul class="nav nav-pills nav-justified">
    <li class="active"><a data-toggle="pill" href="#pastelinks">Paste Links</a></li>
    <li><a data-toggle="pill" href="#fileupload">File Upload</a></li>
    <li><a data-toggle="pill" href="#remoteupload">Remote Upload</a></li>
</ul>

<?php if(System\Session::exists('error')): ?>
<div class="home-error-wrap">
  <div class="alert btn-danger">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo System\Session::flash('error'); ?>
  </div>
</div>
<?php endif; ?>

<form action="protected" method="post" enctype="multipart/form-data" novalidate autocomplete="off">
<div class="tab-content home-content">
    <div id="pastelinks" class="tab-pane active">
          <div class="row">
              <div class="col-md-8 col-md-offset-2">
                <textarea name="data[links]" placeholder="Input list of urls"></textarea>
              </div>
          </div>
    </div>
   
   <div id="fileupload" class="tab-pane">
       <div class="row">
          <div class="col-md-6 col-md-offset-3">
            <span class="btn btn-default" id="show-selected-file">
              <i class="fa fa-plus" aria-hidden="true"></i> 
              Select File
            </span>
            <input id="imageUploader" name="txt" type="file" name="image" class="upload" accept="text/plain">
          </div>
       </div>
    </div>
    
    <div id="remoteupload" class="tab-pane">
      <div class="row">
         <div class="col-md-2 col-md-offset-2">
              <label for="rurl">Remote URL</label>
          </div>
          <div class="col-md-6">
              <input type="url" name="data[remote]" placeholder="Input url here" class="form-control" id="rurl">
          </div>
       </div>
    </div>
</div>

<div class="home-password">
     <div class="row">
        <div class="col-md-4 col-md-offset-1">
          <button type="button" class="btn btn-success" data-toggle="collapse" data-target="#homePassword">
            <i class="fa fa-plus" aria-hidden="true"></i>
            &nbsp;Advance Options
          </button>
          </div>
    </div>
    <div class="row">
        <div id="homePassword" class="collapse col-md-8 col-md-offset-2">
             <div class="form-group">
                <label for="pwd">Encrypt with password:</label>
                <input type="password" placeholder="Encrypt key" name="data[password]" class="form-control" id="pwd">
              </div>
              <div class="form-group">
                <label for="pwd">Title:</label>
                <input type="text" placeholder="Enter a title" name="data[title]" class="form-control" id="pwd">
              </div>
        </div>
    </div>  
</div>

<div class="home-content-submit row">
      <div class="col-md-3 col-md-offset-5 btn-block">
          <button class="btn btn-primary btn-lg" type="submit">
            <i class="fa fa-md fa-cloud-upload"></i> 
            Protect My Links
          </button>
      </div>
    <div class="row">
      <div class="sumit-terms col-md-5 col-md-offset-4">
        By uploading links to our site you agree to the <a href="/page/terms">Terms of use</a>
      </div>
    </div>
</div>

</form>

</div>

<?php $this->xinclude('partials/footer'); ?>
