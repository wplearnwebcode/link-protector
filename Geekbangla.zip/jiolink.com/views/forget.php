<?php $this->xinclude('partials/header'); ?>
    <div class="register-wrapper">
        <form class="form-horizontal" action="" method="post">
            <h1 class="register-title">Forget password?</h1>

        <?php if(System\Session::exists('error')): ?>
            <div class="home-error-wrap">
              <div class="alert btn-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>*</strong> <?php echo System\Session::flash('error'); ?>
              </div>
            </div>
        <?php endif; ?>

        <?php if(System\Session::exists('success')): ?>
            <div class="home-error-wrap">
                <div class="alert alert-success view-success">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                  <h1><i class="fa fa-check" aria-hidden="true"></i>
                  &nbsp; <?php echo System\Session::flash('success'); ?></h1>
                </div>
            </div>
        <?php endif; ?>

            <div class="row">
                <div class="form-group">
                  <label class="control-label col-sm-2" for="email">Email:</label>
                  <div class="col-sm-6">
                    <input type="text" name="email" class="form-control" id="email" placeholder="Enter email">
                  </div>
                </div>
                  <div class="form-group">
                  <label class="control-label col-sm-2">Captcha:</label>
                  <div class="col-sm-6">
                       <div class="g-recaptcha" data-sitekey="<?php echo System\Config::google('key'); ?>"></div>
                  </div>
                </div>
              <div class="col-sm-3 col-sm-offset-1">
                <button type="submit" class="btn btn-default btn-block">Reset Password</button>
              </div>
            </div>
        </form>

    </div>
<?php $this->xinclude('partials/footer'); ?>