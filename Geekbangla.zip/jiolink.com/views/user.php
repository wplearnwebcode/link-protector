<?php $this->xinclude('partials/header'); ?>

<div class="register-wrapper">
    <form class="form-horizontal" method="post" action="">
        
        <?php if(System\Session::exists('error')): ?>
            <div class="home-error-wrap">
              <div class="alert btn-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo System\Session::flash('error'); ?>
              </div>
            </div>
        <?php endif; ?>

        <?php if(System\Session::exists('success')): ?>
            <div class="home-error-wrap">
                <div class="alert alert-success view-success">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                  <h1><i class="fa fa-check" aria-hidden="true"></i>
                  &nbsp; <?php echo System\Session::flash('success'); ?></h1>
                </div>
            </div>
        <?php endif; ?>
        
        <h1 class="register-title">User Settings</h1>

        <div class="row">
            <div class="form-group">
                <label class="control-label col-sm-2" for="username">Username:</label>
                <div class="col-sm-6">
                  <input type="text" name="username" class="form-control" value="<?php echo $this->userData->username; ?>" id="username" placeholder="Enter username" >
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="email">Email:</label>
                <div class="col-sm-6">
                  <input type="email" name="email" value="<?php echo $this->userData->email; ?>" class="form-control" id="email" placeholder="Enter email">
                </div>
            </div>
        
            <hr/>

            <div class="form-group">
                <label class="control-label col-sm-2" for="opasssword">Old password:</label>
                <div class="col-sm-6">
                  <input type="password" name="opasssword" class="form-control" id="opasssword" placeholder="Enter old password (Optional If there ain't any)">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="npassword">New password:</label>
                <div class="col-sm-6">
                  <input type="password" name="npassword" class="form-control" id="npassword" placeholder="Enter new password">
                </div>
            </div>

            <hr/>

            <div class="form-group">
                <label class="control-label col-sm-2" for="payment-via">Payment Via:</label>
                <div class="col-sm-6">
                      <select name="payment" id="payment-via" class="contact-select">
                        <?php   

                            foreach ($this->paymentArray as $k) {

                                $selected = ($this->userData->payment_id == $k->id)? 'selected' : '';
                               
                               echo '<option value="'.$k->name.'" '.$selected.'>'.ucwords($k->name).'</option>';
                            }

                        ?>
                     </select>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-2" for="payment-id">Payment ID:</label>
                <div class="col-sm-6">
                     <input type="text" name="payment_value" value="<?php echo $this->userData->payment_value; ?>" class="form-control" id="payment-id" placeholder="Specifiy payment id or account no">
                </div>
            </div>

            <div class="col-sm-3 col-sm-offset-1">
                <button type="submit" class="btn btn-default btn-block">Save Settings</button>
              </div>

        </div>
    </form>
</div>

<?php $this->xinclude('partials/footer'); ?>