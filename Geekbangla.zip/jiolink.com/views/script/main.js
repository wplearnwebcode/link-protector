$(function(){


/**
 * File upload change status
 */
$('#imageUploader').on('change', function(){
  var value = this.value;
  if(!value) return;
  value = value.split(/[\/\\]/).pop()
  $('#show-selected-file').text(value).css('background', '#eee');
});



});