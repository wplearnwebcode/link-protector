﻿     </div>
</section>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 footer-copyright">
                © JioLink 2017-2018
            </div>
            <div class="col-sm-8 footer-nav">
                 <ul class="nav navbar-nav">
                  <li><a href="/page/privacy">Privacy Policy</a></li>
                  <li><a href="/page/terms">Terms</a></li>
                  <li><a href="/faqs">Faqs</a></li> 
                  <li><a href="/page/dmca">Dmca Copyright</a></li> 
                </ul>
            </div>
        </div>
    </div>
</footer>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="/script/bootstrap.min.js"></script>
<script src="/script/main.js"></script>

<?php if(in_array($this->pageType, ['view', 'forget'])): ?>
<script src="//www.google.com/recaptcha/api.js" async></script>
<?php endif; ?>
</body>
</html>