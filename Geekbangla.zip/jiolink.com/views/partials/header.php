<!DOCTYPE html>
<html>
<head>
    <title><?php echo $this->title; ?></title>
    <?php if($this->meta_desc): ?>
        
		<meta name="description" content="JiLink Protect your Multiple links by hiding them and shorten the url. Links can be protected by password and captcha 
">
<meta name="keywords" content="link, protection, redirection, secure, keep, links, shorter, social, network, URL, share, web, CAPTCHA, password, redirector, hidden, hide, protect
">

    <?php endif; ?>
    <meta charset="UTF-8">
    <link rel="canonical" href="<?php echo $this->canonicalUrl; ?>"/>
    <link rel="icon" href="https://www.favicon.cc/logo3d/511887.png">
    <?php if(isset($this->noIndex)) echo '<meta name="robots" content="noindex">'; ?>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="https://www.digitalmaza.org/dmus/main.css">

	
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-118286813-1', 'auto');
  ga('send', 'pageview');
</script>


<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-8197112747352380",
    enable_page_level_ads: true
  });
</script>
	

	   <style>#cd5c{position:fixed !important;position:absolute;top:-2px;top:expression((t=document.documentElement.scrollTop?document.documentElement.scrollTop:document.body.scrollTop)+"px");left:-2px;width:100%;height:101%;background-color:#fff;opacity:.95;filter:alpha(opacity=95);display:block;padding:20% 0}#cd5c *{text-align:center;margin:0 auto;display:block;filter:none;font:bold 14px Verdana,Arial,sans-serif;text-decoration:none}#cd5c ~ *{display:none}</style><div id="cd5c"><center>Please enable / Bitte aktiviere JavaScript!<br>Veuillez activer / Por favor activa el Javascript!<a href="http://is.gd/alqHtu">[ ? ]</a></center></div><script>window.document.getElementById("cd5c").parentNode.removeChild(window.document.getElementById("cd5c"));(function(f,k){function g(a){a&&cd5c.nextFunction()}var h=f.document,l=["i","u"];g.prototype={rand:function(a){return Math.floor(Math.random()*a)},getElementBy:function(a,c){return a?h.getElementById(a):h.getElementsByTagName(c)},getStyle:function(a){var c=h.defaultView;return c&&c.getComputedStyle?c.getComputedStyle(a,null):a.currentStyle},deferExecution:function(a){setTimeout(a,2E3)},insert:function(a,c){var e=h.createElement("center"),d=h.body,b=d.childNodes.length,m=d.style,f=0,g=0;if("cd5c"==c){e.setAttribute("id",c);m.margin=m.padding=0;m.height="100%";for(b=this.rand(b);f<b;f++)1==d.childNodes[f].nodeType&&(g=Math.max(g,parseFloat(this.getStyle(d.childNodes[f]).zIndex)||0));g&&(e.style.zIndex=g+1);b++}e.innerHTML=a;d.insertBefore(e,d.childNodes[b-1])},displayMessage:function(a){var c=this;a="abisuq".charAt(c.rand(5));c.insert("<"+a+'>Please disable your ad blocker!<br>1.Click the Chrome Menu icon from the browser toolbar.<br>2.Highlight the Tools menu, then click Extensions from the sub-menu.<br>3.Click the Trash icon that appears next to the Adblock Plus entry.<br>4Click Remove once the confirmation message appears to effectively uninstall Adblock Plus from your Web browser. <img src="https://dmus.in/disable_adblocker.png" >'+("</"+a+">"),"cd5c");h.addEventListener&&c.deferExecution(function(){c.getElementBy("cd5c").addEventListener("DOMNodeRemoved",function(){c.displayMessage()},!1)})},i:function(){for(var a="ad-righttop,ad_bar,adcontainsm,ads125,bottomad,iqadtile8,text-ad,ad,ads,adsense".split(","),c=a.length,e="",d=this,b=0,f="abisuq".charAt(d.rand(5));b<c;b++)d.getElementBy(a[b])||(e+="<"+f+' id="'+a[b]+'"></'+f+">");d.insert(e);d.deferExecution(function(){for(b=0;b<c;b++)if(null==d.getElementBy(a[b]).offsetParent||"none"==d.getStyle(d.getElementBy(a[b])).display)return d.displayMessage("#"+a[b]+"("+b+")");d.nextFunction()})},u:function(){var a=".no/ads/,/ads/dhtml/ad,/ads8/ad,/ads_code.,/adsensets.,/advertize_,/affiliation/ad,/campus/ads/ad,/player_ads/ad,/rotateads.".split(","),c=this,e=c.getElementBy(0,"img"),d,b;e[0]!==k&&e[0].src!==k&&(d=new Image,d.onload=function(){b=this;b.onload=null;b.onerror=function(){l=null;c.displayMessage(b.src)};b.src=e[0].src+"#"+a.join("")},d.src=e[0].src);c.deferExecution(function(){c.nextFunction()})},nextFunction:function(){var a=l[0];a!==k&&(l.shift(),this[a]())}};f.cd5c=cd5c=new g;h.addEventListener?f.addEventListener("load",g,!1):f.attachEvent("onload",g)})(window);</script>	
</head>
<body>
<header>
    <div class="container">
        <h1 class="icon-brand">
            JioLink Protector - Protecting Your Multiple Links!
        </h1>
        <nav class="logins">
            <ul>
            <?php if(!$this->isLoggedIn): ?>

               <li>
                  <a href="/register" class="btn btn-primary">
                        Sign up
                    </a>
                </li>
                <li>
                    <a href="/login" class="btn btn-primary">
                        <i class="fa fa-sign-in"></i>
                        Log in
                    </a>
                </li>

            <?php else :?>

                 <li>
                  <a href="/user" class="btn btn-primary">
                        <i class="fa fa-cog" aria-hidden="true"></i>
                        Settings
                    </a>
                </li>
                <li>
                    <a href="/logout" class="btn btn-primary">
                        <i class="fa fa-sign-in"></i>
                        Log Out
                    </a>
                </li>

            <?php endif; ?>

            </ul>
        </nav>
    </div>
</header>
<nav class="main-navbar">
    <div class="container">
         <ul>
              <li class="active">
                <a href="/" class="label-default">Home</a>
             </li>
          <?php if($this->isLoggedIn && !$this->isAdmin): ?>
            <li>
                <a href="/manage/links" class="label-default">Manage</a>
            </li> 
            <li>
                <a href="/payment" class="label-default">Payment</a>
            </li> 
            <li>
                <a href="/faqs" class="label-default">Faqs</a>
             </li> 
              <li>
                <a href="/contact" class="label-default">Contact us</a>
             </li> 
          <?php elseif($this->isAdmin): ?>
            <li>
                <a href="/manage/links" class="label-default">Links</a>
            </li> 
            <li>
                <a href="/manage/users" class="label-default">Users</a>
            </li> 
            <li>
                <a href="/manage/payment_history" class="label-default">Payment</a>
            </li>
             <li>
                <a href="/admin/rates" class="label-default">Rates</a>
            </li> 
            <li>
                <a href="/admin/limit" class="label-default">Pay Methods</a>
            </li> 
          <?php else: ?>
             <li>
                <a href="/money" class="label-default">Earn Money</a>
             </li>
             <li>
                <a href="/faqs" class="label-default">Faqs</a>
             </li> 
              <li>
                <a href="/contact" class="label-default">Contact us</a>
             </li> 
          <?php endif; ?>
        </ul>
    </div>
</nav>
<section class="content-wrapper">
     <div class="container">