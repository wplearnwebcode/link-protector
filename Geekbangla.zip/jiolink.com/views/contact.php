<?php $this->xinclude('partials/header'); ?>
    <div class="register-wrapper">
        <form class="form-horizontal" method="post" action="">
            <h1 class="register-title">Contact us</h1>

          <?php if(System\Session::exists('error')): ?>
            <div class="home-error-wrap">
              <div class="alert btn-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>*</strong> <?php echo System\Session::flash('error'); ?>
              </div>
            </div>
          <?php endif; ?>

          <?php if(System\Session::exists('success')): ?>
            <div class="home-error-wrap">
                <div class="alert alert-success view-success">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                  <h1><i class="fa fa-check" aria-hidden="true"></i>
                  &nbsp; <?php echo System\Session::flash('success'); ?></h1>
                </div>
            </div>
        <?php endif; ?>

            <div class="row">
                <div class="form-group">
                  <label class="control-label col-sm-2" for="name">Name:</label>
                   <div class="col-sm-6">
                      <input type="text" name="data[name]" <?php if($this->isLoggedIn) echo 'value="'.$this->userData->username.'"'; ?> class="form-control" id="name" placeholder="Enter name" required>
                    </div>
              </div>
               <div class="form-group">
                  <label class="control-label col-sm-2" for="email">Email:</label>
                   <div class="col-sm-6">
                      <input type="email" name="data[email]" <?php if($this->isLoggedIn) echo 'value="'.$this->userData->email.'"'; ?> class="form-control" id="email" placeholder="Enter email" required>
                    </div>
              </div>
               <div class="form-group">
                <label class="control-label col-sm-2" for="topic">Topic:</label>
                <div class="col-sm-6"> 
                  <select name="data[topic]"" id="topic" class="contact-select">
                    <option value="general">General</option>
                    <option value="technical">Technical</option>
                    <option value="dmca">DMCA Report</option>
                    <option value="advertising">Advertising</option>
                    <option value="other">Other</option>
                </select>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-2" for="contact-message">Message:</label>
                <div class="col-sm-6"> 
                  <textarea id="contact-message" name="data[message]" placeholder="Enter message here" required=""></textarea>
                </div>
              </div>
              <div class="col-sm-3 col-sm-offset-1">
                <button type="submit" class="btn btn-default btn-block">Send message</button>
              </div>
            </div>
        </form>

    </div>
<?php $this->xinclude('partials/footer'); ?>