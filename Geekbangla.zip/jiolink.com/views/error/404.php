<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html>
<head>
    <title>404 Not Found</title>
</head>
<style>
abbr,address,article,aside,audio,b,blockquote,body,canvas,caption,cite,code,dd,del,details,dfn,div,dl,dt,em,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hgroup,html,i,iframe,img,ins,kbd,label,legend,li,mark,menu,nav,object,ol,p,pre,q,samp,section,small,span,strong,sub,summary,sup,table,tbody,td,tfoot,th,thead,time,tr,ul,var,video {
    margin: 0;
    padding: 0;
    border: 0;
    outline: 0;
    font-size: 100%;
    vertical-align: baseline;
    background: 0 0;
}

body {
    line-height: 1;
}

* {
    box-sizing: border-box;
}

html {
    background-color: #f06060;
    color: #fff;
    font-size: 16px;
    font-family: 'Open Sans',sans-serif;
}

@media screen and (max-width:600px) {
    html {
        font-size: 10px;
    }
}

#container {
    width: calc(100% - 100px);
    max-width: 1200px;
    min-width: 300px;
    margin: 0 auto;
    padding: 50px;
}

h1 {
    font-size: 16rem;
}

h2 {
    font-size: 6rem;
    color: #f48f8f;
}

p {
    font-size: 4rem;
    color: #f48f8f;
    font-weight: bold;
}

a{
    text-decoration: none;
    color: #eee;
}

a:hover{
    text-decoration: underline;
}

@font-face {
    font-family:'Open Sans';
    font-style:normal;
    font-weight:700;
}
</style>
<body>
 <div id="container">
  <h1>404</h1>
  <h2>There isn't anything here</h2>
  <br/>
  <br/>
  <p>Go to <a href="/">homepage</a></p>
</div>
</body>
</html>