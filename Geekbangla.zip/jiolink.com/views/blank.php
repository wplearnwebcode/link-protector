<?php $this->xinclude('partials/header'); ?>
<?php $this->xinclude('partials/footer'); ?>