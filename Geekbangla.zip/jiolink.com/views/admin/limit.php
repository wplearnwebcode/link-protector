<?php $this->xinclude('partials/header'); ?>
<?php if(System\Session::exists('success')): ?>
    <div class="home-error-wrap">
        <div class="alert alert-success view-success">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <h1><i class="fa fa-check" aria-hidden="true"></i>
          &nbsp; <?php echo System\Session::flash('success'); ?></h1>
        </div>
    </div><br/>
<?php endif; ?>

<div class="edit-links-wrapper"> 
        <h1 class="register-title">Payment Methods & Limits</h1>
        <div class="tab-content home-content">
            <table class="table table-bordered table-hover">
               <thead>
                <tr>
                  <th>Method</th>
                  <th>Limit</th>
                </tr>
              </thead>
              <tbody>
                <?php 

                foreach ($this->methods as $k) {
                    
                    echo '<tr>
                        <td>'.ucwords($k->name).'</td>
                        <td>$'.$k->minimum.'</td>
                      </tr>';
                  
                }

                ?>
              </table>
        </div>

  <br/>
  <h1 class="register-title">Change Limit</h1>
    <form class="form-horizontal" method="post" action="">  
        <div class="form-group">
            <label class="control-label col-sm-2" for="payment-via">Choose Method</label>
            <div class="col-sm-6">
                  <select name="limit[name]" id="payment-via" class="contact-select">
                     <?php 
                      foreach ($this->methods as $k) {
                          echo '<option value="'.$k->id.'">'.ucwords($k->name).'</option>';
                      }
                      ?>                 
                  </select>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-2" for="payment-id">New Limit:</label>
            <div class="col-sm-6">
                 <input type="text" name="limit[minimum]" value="" class="form-control" id="payment-id" placeholder="Specifiy new limit" required="">
            </div>
        </div>
        <div class="col-sm-3 col-sm-offset-1">
            <button type="submit" class="btn btn-default btn-block">Change it</button>
        </div>
   </form>

  <br/>
  <div style="clear:both"></div>
  <br/>
  <h1 class="register-title">Add Method</h1>
    <form class="form-horizontal" method="post" action="">  
        <div class="form-group">
            <label class="control-label col-sm-2" for="method-name">Method Name:</label>
            <div class="col-sm-6">
                 <input type="text" name="add[name]" value="" class="form-control" id="method-name" placeholder="Method name" required="">
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-2" for="method-minimum">Minimum Limit:</label>
            <div class="col-sm-6">
                 <input type="text" name="add[minimum]" value="" class="form-control" id="method-minimum" placeholder="Specifiy limit" required="">
            </div>
        </div>
        <div class="col-sm-3 col-sm-offset-1">
            <button type="submit" class="btn btn-default btn-block">Add it</button>
          </div>
   </form>

  <br/>
  <div style="clear:both"></div>
  <br/>
  <h1 class="register-title">Remove Method</h1>
    <form class="form-horizontal" method="post" action="">  
        <div class="form-group">
            <label class="control-label col-sm-3" for="remove-method">Choose Method (careful!)</label>
            <div class="col-sm-6">
                  <select name="remove[name]" id="remove-method" class="contact-select">
                    <option value="">Choose it</option>
                    <?php 
                      foreach ($this->methods as $k) {
                          echo '<option value="'.$k->id.'">'.ucwords($k->name).'</option>';
                      }
                      ?>                 
                  </select>
            </div>
        </div>
        <div class="col-sm-3 col-sm-offset-1">
            <button type="submit" class="btn btn-danger btn-block">Remove it</button>
        </div>
   </form>

</div>


<?php $this->xinclude('partials/footer'); ?>