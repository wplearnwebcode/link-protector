<?php $this->xinclude('partials/header'); ?>
<?php if(System\Session::exists('success')): ?>
    <div class="home-error-wrap">
        <div class="alert alert-success view-success">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <h1><i class="fa fa-check" aria-hidden="true"></i>
          &nbsp; <?php echo System\Session::flash('success'); ?></h1>
        </div>
    </div><br/>
<?php endif; ?>

<div class="edit-links-wrapper"> 
        <h1 class="register-title">Payment rates</h1>
        <div class="tab-content home-content">
            <table class="table table-bordered table-hover">
               <thead>
                <tr>
                  <th>GROUP</th>
                  <th>AMOUNT (PER 1000)</th>
                  <th>COUNTRY</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>A</td>
                  <td>$<?php echo $this->rates['a']; ?></td>
                  <td>United States, United Kingdom</td>
                </tr>
                <tr>
                  <td>B</td>
                  <td>$<?php echo $this->rates['b']; ?></td>
                  <td>Netherlands, Germany, France, Canada, Australia</td>
                </tr>
                <tr>
                  <td>C</td>
                  <td>$<?php echo $this->rates['c']; ?></td>
                  <td>Spain, Iran</td>
                </tr>
                <tr>
                  <td>D</td>
                  <td>$<?php echo $this->rates['d']; ?></td>
                  <td>Other</td>
                </tr>
              </table>
        </div>
        <h1 class="register-title">Change Rates</h1>
    <form class="form-horizontal" method="post" action="">  
        <div class="form-group">
            <label class="control-label col-sm-2" for="payment-via">Change rates of:</label>
            <div class="col-sm-6">
                  <select name="group" id="payment-via" class="contact-select">
                    <option value="1">Group A</option>
                    <option value="2">Group B</option> 
                    <option value="3">Group C</option> 
                    <option value="4">Group D</option>                    
                  </select>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-2" for="payment-id">New Rates:</label>
            <div class="col-sm-6">
                 <input type="text" name="rate" value="" class="form-control" id="payment-id" placeholder="Specifiy new rate" required="">
            </div>
        </div>
        <div class="col-sm-3 col-sm-offset-1">
            <button type="submit" class="btn btn-default btn-block">Save Settings</button>
          </div>
   </form>

</div>




<?php $this->xinclude('partials/footer'); ?>