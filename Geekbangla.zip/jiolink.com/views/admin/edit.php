<?php $this->xinclude('partials/header'); ?>
<?php if(System\Session::exists('success')): ?>
    <div class="home-error-wrap">
        <div class="alert alert-success view-success">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <h1><i class="fa fa-check" aria-hidden="true"></i>
          &nbsp; <?php echo System\Session::flash('success'); ?></h1>
        </div>
    </div><br/>
<?php endif; ?>

<div class="edit-links-wrapper"> 
    <form class="form-horizontal" method="post" action="">  
        <h1 class="register-title">Edit Payment Status</h1>
        <div class="tab-content home-content">
            <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">User:</label>
                <div class="col-sm-6"> 
                  <input type="text" value="<?php echo ucwords($this->payment_data->username); ?>" class="form-control" id="pwd" disabled="">
                </div>
            </div>
             <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">Amount:</label>
                <div class="col-sm-6"> 
                  <input type="text" value="$<?php echo ucwords($this->payment_data->amount); ?>" class="form-control" id="pwd" disabled="">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">Created:</label>
                <div class="col-sm-6"> 
                  <input type="text" value="<?php echo ucwords($this->payment_data->created); ?>" class="form-control" id="pwd" disabled="">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">Payment Gateway:</label>
                <div class="col-sm-6"> 
                  <input type="text" value="<?php echo ucwords($this->payment_data->payment_name); ?>" class="form-control" id="pwd" disabled="">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">Payment ID:</label>
                <div class="col-sm-6"> 
                  <input type="text" value="<?php echo ucwords($this->payment_data->payment_value); ?>" class="form-control" id="pwd" disabled="">
                </div>
            </div>
            <div class="form-group">
            <label class="control-label col-sm-2 mainLabel">Payment Status</label>
                <div class="col-lg-10">
                    <div class="radio radioButton">
                        <label class="radio">
                          <input type="radio" <?php if($this->payment_data->status == 'completed') echo "checked"; ?> name="status" id="status_0" value="completed">
                            Completed
                        </label>
                        <label class="radio">
                          <input type="radio" <?php if($this->payment_data->status == 'pending') echo "checked"; ?>  name="status" id="status_0" value="pending">
                              Pending
                        </label>
                    </div>
                 </div>
            </div>    
    </div>
</div>
<div class="home-content-submit row">
  <div class="col-md-3 col-md-offset-3 btn-block">
      <button class="btn btn-success btn-lg" type="submit">
        Change Payment Status
      </button>
  </div>
</div>
</form>

<?php $this->xinclude('partials/footer'); ?>