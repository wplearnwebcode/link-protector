<?php $this->xinclude('partials/header'); ?>

<div class="protected-wrap">
    <h1 class="protected-title">Your Protected Links</h1>

    <div class="alert alert-success">
      <i class="fa fa-check" aria-hidden="true"></i> &nbsp; <strong>Success!</strong> your links successfully protected.
    </div>

    <div class="well">
        <h3 class="label label-success">Protected link</h3>
        <a href="/view/<?php echo $this->uid; ?>" target="_blank"><?php echo System\Config::app('scheme').'://'.System\Config::app('domain').'/view/'.$this->uid; ?></a>
    </div>


    <div class="well">
        <h3 class="label label-warning">Remove link</h3>
        <a href="/remove/<?php echo $this->delete_uid; ?>" target="_blank"><?php echo System\Config::app('scheme').'://'.System\Config::app('domain').'/remove/'.$this->delete_uid; ?></a>
    </div>

</div>

<?php $this->xinclude('partials/footer'); ?>