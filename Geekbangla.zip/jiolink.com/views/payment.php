<?php $this->xinclude('partials/header'); ?>

<div class="payment-wrapper">
 <h1 class="register-title">Earnings</h1>
    <div class="row">
        <div class="col-sm-4 col-sm-offset-1 well">
            <div class="col-sm-6">
                Current Balance
            </div>
            <div class="col-sm-6">
                $<?php echo $this->current_balance; ?>
            </div>
        </div>
        <div class="col-sm-3 well">
            <div class="col-sm-6">
                Total Payout
            </div>
            <div class="col-sm-6">
                $<?php echo $this->total_payout;?>
            </div>
        </div>
        <div class="col-sm-3 well">
            <div class="col-sm-6">
                Pending
            </div>
            <div class="col-sm-6">
                <?php echo $this->pending_amount; ?>
            </div>
        </div>
    </div>
  
  <?php if(!$this->isAdmin): ?>

    <h1 class="register-title">Request Payment</h1>

        <?php if(System\Session::exists('error')): ?>
            <div class="home-error-wrap">
              <div class="alert btn-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo System\Session::flash('error'); ?>
              </div>
            </div><br/>
        <?php endif; ?>

        <?php if(System\Session::exists('success')): ?>
            <div class="home-error-wrap">
                <div class="alert alert-success view-success">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                  <h1><i class="fa fa-check" aria-hidden="true"></i>
                  &nbsp; <?php echo System\Session::flash('success'); ?></h1>
                </div>
            </div><br/><br/>
        <?php endif; ?>

    <form class="form-horizontal" method="post" action="">
        <div class="row">
             <div class="form-group">
               <label class="control-label col-sm-2" for="amount">Amount:</label>
               <div class="col-sm-6">
                  <input type="text" name="amount" class="form-control" id="amount" placeholder="Enter amount" required="">
                </div>
              </div>
              <div class="col-sm-3 col-sm-offset-1">
                <button type="submit" class="btn btn-default btn-block">Request</button>
              </div>
        </div>
    </form>
  <?php endif; ?>
  
    <h1 class="register-title">Payment History</h1>
    <div class="row">
        <div class="col-sm-6 col-sm-offset-1">
        <table class="table table-bordered table-hover">
         <thead>
          <tr>
            <th>Date</th>
            <th>Status</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($this->payment_history as $k) {
          
        echo '<tr>
            <td>'.date('d M Y', strtotime($k->created)).'</td>
            <td>'.ucfirst($k->status).'</td>
            <td>$'.$k->amount.'</td>
          </tr>';

            }

          ?>
        </table>
        </div>
    </div>
</div>

<?php $this->xinclude('partials/footer'); ?>