<?php $this->xinclude('partials/header'); ?>
<div class="money-wrap faq-section">
    <h1 class="money-heading">
        Faqs
    </h1>
    <div class="panel-group" id="accordion">

    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">What is JioLink?</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse in">
        <div class="panel-body">
           It is a free service that helps you protect your links from inconvenient people or automated robots with security such as captcha and password. we will convert your links to direct links that will act as autoforwarders to your original links. In addition, we optionally provide you with the ability to limited access to those direct links with a CAPTCHA or/and password. This protection will appear on a protected page. We also offer you the opportunity to shorten a long website address.
        </div>
      </div>
    </div>

    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">How can I protect url on linkshub?</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">The easiest and most common way to protected links through our service is to 
        go to our main page (home page), input your links in the text area (box) and press the "Protect your links" button. 
        This will generate a results page where several outputs will be listed, such as generated protected links, direct links and remove links. go to 'Advanced Options' on (home page) to set your settings before submitting.</div>
      </div>
    </div>

    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">How can I delete/remove protected link?</a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="panel-body">You can delete protected link with unique removal id, that you get after protect url on site (result page). Also you can delete protected links from your account "Manage Links" section.</div>
      </div>
    </div>

    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">What is the difference between a direct and a protected link?</a>
        </h4>
      </div>
      <div id="collapse4" class="panel-collapse collapse">
        <div class="panel-body">
            A direct link is a simple forwarder to the original link you have inputted (using a HTTP redirection). Those direct links do not have any protection system. They are fully compatible with any download managers.
            A protected link will point to a security page where a CAPTCHA or a password form will get displayed and required to be completed in order to access direct/live links (original links) listing.
        </div>
      </div>
    </div>

    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse5">Can i use your service without register?</a>
        </h4>
      </div>
      <div id="collapse5" class="panel-collapse collapse">
        <div class="panel-body">
           Yes, you can use our service without creating any account on site.
        </div>
      </div>
    </div>

    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse6">
            What are the benefits of registering an account?
          </a>
        </h4>
      </div>
      <div id="collapse6" class="panel-collapse collapse">
        <div class="panel-body">
          A personal account will allow you to manage the protected links you create on our site. You will be able to edit, duplicate and delete them. See your complete protected links history. with a advance search feature. you can search your submitted links with protected url or original filename.
        </div>
      </div>
    </div>

    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse7">
            How can I register an account?
          </a>
        </h4>
      </div>
      <div id="collapse7" class="panel-collapse collapse">
        <div class="panel-body">
           All you need to do is simply click on the 'Register' button. You will be prompted by a dialog asking you for a username and an e-mail address from there, a password will be sent to your e-mail address with activation code and you will be able to get started after activate your account.
        </div>
      </div>
    </div>

    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse8">
            I forgot my password or username. How do I recover them?
          </a>
        </h4>
      </div>
      <div id="collapse8" class="panel-collapse collapse">
        <div class="panel-body">
           Just click on the 'Forgot Password' link at the top right of the screen. You will be prompted by a small dialog and all you need to do is enter correct email address and submit... check our mail on inbox to recover your username or password.
        </div>
      </div>
    </div>

    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse9">
            How can I report improper links?
          </a>
        </h4>
      </div>
      <div id="collapse9" class="panel-collapse collapse">
        <div class="panel-body">
           If you are holder of an intellectual property right or you are an agent of such, and you feel that a keeplinks.me violates this right, you may send us a DMCA report by using the 'Contact Us' button. we make sure to handle these reports the quickest possible. You also use contact us to report links pointing to dangerous materials (virus) - illegal pornography or anything used to cause harm to our users.
        </div>
      </div>
    </div>

        <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse10">
            I still have questions, what should I do?
          </a>
        </h4>
      </div>
      <div id="collapse10" class="panel-collapse collapse">
        <div class="panel-body">
           If you still have questions regarding our service please don't hesitate to contact us using <a href="https://linkshub.me/contact">our page</a>
        </div>
      </div>
    </div>

  </div>
</div>
<?php $this->xinclude('partials/footer'); ?>