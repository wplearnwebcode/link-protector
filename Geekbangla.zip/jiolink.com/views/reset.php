<?php $this->xinclude('partials/header'); ?>
<div class="register-wrapper">
 <h1 class="register-title">Reset password?</h1>
<?php if(System\Session::exists('error')): ?>
    <hr/>
    <div class="home-error-wrap">
      <div class="alert btn-danger">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>*</strong> <?php echo System\Session::flash('error'); ?>
      </div>
    </div>
    <hr/>
    <div class="row">
        <div class="col-sm-4 col-sm-offset-5">
            <a href="/" class="btn btn-primary">
                Go back to home page
            </a>
        </div>
    </div>

<?php else: ?>

    <form class="form-horizontal" action="" method="post">

    <?php if(System\Session::exists('passerror')): ?>
      <div class="home-error-wrap">
        <div class="alert btn-danger">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo System\Session::flash('passerror'); ?>
        </div>
      </div>
    <?php endif; ?>
        
        <div class="form-group">
          <label class="control-label col-sm-2" for="npassword">New Password:</label>
          <div class="col-sm-6">
            <input type="password" name="npassword" class="form-control" id="npassword" required="">
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-sm-2" for="rpassword">Repeat Password:</label>
          <div class="col-sm-6">
            <input type="password" name="rpassword" class="form-control" id="rpassword" required="">
          </div>
        </div>

        <div class="col-sm-3 col-sm-offset-1">
            <button type="submit" class="btn btn-default btn-block">Change Password</button>
        </div>

    </form>

<?php endif; ?>
</div>
<?php $this->xinclude('partials/footer'); ?>