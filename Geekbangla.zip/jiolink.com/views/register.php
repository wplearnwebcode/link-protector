<?php $this->xinclude('partials/header'); ?>

    <div class="register-wrapper">
        <form class="form-horizontal" method="post" action="" autocomplete="off">
            <h1 class="register-title">Create a free account</h1>

          <?php if(System\Session::exists('error')): ?>
            <div class="home-error-wrap">
              <div class="alert btn-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>*</strong> <?php echo System\Session::flash('error'); ?>
              </div>
            </div>
          <?php endif; ?>

          <?php if(System\Session::exists('success')): ?>

            <div class="row home-success">
              <div class="col-sm-8 col-sm-offset-2 alert-success">
                  <h1>You registered successfully!</h1>
                   <br/><a class="btn btn-default" href="/login">Click here to login</a>
              </div>
            </div>


          <?php System\Session::flash('success'); else: ?>


            <div class="row">
                <div class="form-group">
                  <label class="control-label col-sm-2" for="username">Username:</label>
                   <div class="col-sm-6">
                      <input type="text" name="username" class="form-control" id="username" placeholder="Enter username" required>
                    </div>
                </div>
               <div class="form-group">
                  <label class="control-label col-sm-2" for="email">Email:</label>
                   <div class="col-sm-6">
                      <input type="email" name="email" class="form-control" id="email" placeholder="Enter email" required>
                    </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">Password:</label>
                <div class="col-sm-6"> 
                  <input type="password" name="password" class="form-control" id="pwd" placeholder="Enter password" required>
                </div>
              </div>
              <div class="col-sm-3 col-sm-offset-1">
                <button type="submit" class="btn btn-default btn-block">Register</button>
              </div>
            </div>
        </form>

        <hr/>

        <div class="row">
            <div class="col-sm-3 col-sm-offset-1">
                <a href="/loginwith/facebook" class="btn social-facebook">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                    Signup with facebook
                </a>
            </div>
            <div class="col-sm-3">
                 <a href="/loginwith/google" class="btn social-google">
                    <i class="fa fa-google-plus" aria-hidden="true"></i>
                    Signup with google
                </a>
            </div>
        </div>

      <?php endif; ?>

    </div>

<?php $this->xinclude('partials/footer'); ?>