<?php $this->xinclude('partials/header'); ?>

<div class="register-wrapper">

    <hr/>
    <div class="row">
        <div class="col-sm-8 col-sm-offset-2 alert alert-success view-success">
          <h1><i class="fa fa-check" aria-hidden="true"></i>
          &nbsp;Link Successfully removed.</h1>
        </div>
    </div>
    <hr/>
    <div class="row">
        <div class="col-sm-4 col-sm-offset-5">
            <a href="/" class="btn btn-primary">
                Go back to home page
            </a>
        </div>
    </div>
</div>
<?php $this->xinclude('partials/footer'); ?>