<?php $this->xinclude('partials/header'); ?>
<div class="money-wrap">
    <h1 class="money-heading">
        Linkshub pay per view program
    </h1>

    <p>
        The <strong>JioLink</strong> rewards program offer to you the perfect opportunity to earn money by sharing your protected links with your friends and familly. There are no restrictions for any country and anyone can use our free service.
    </p>
    <p>
        The program is open to anyone with an account so register a free account and you'll get paid dailly with no traffic shaving, and no hidden rules.
    </p>

    <h2>Our Rates</h2>
    <table class="table table-bordered table-hover">
     <thead>
      <tr>
        <th>GROUP</th>
        <th>AMOUNT (PER 1000)</th>
        <th>COUNTRY</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>A</td>
        <td>$<?php echo $this->rates['a']; ?></td>
        <td>United States, United Kingdom</td>
      </tr>
      <tr>
        <td>B</td>
        <td>$<?php echo $this->rates['b']; ?></td>
        <td>Netherlands, Germany, France, Canada, Australia</td>
      </tr>
      <tr>
        <td>C</td>
        <td>$<?php echo $this->rates['c']; ?></td>
        <td>Spain, Iran</td>
      </tr>
      <tr>
        <td>D</td>
        <td>$<?php echo $this->rates['d']; ?></td>
        <td>Other</td>
      </tr>
    </table>
     <h2>Rules to follow</h2>
     <ul>
        <li>Unique IP is counted once per 24 hours, user must view the final page of the protected link.</li>
        <li>Protected link must be have captcha enable to qualify for reward program.</li>
        <li>You can protect unlimited urls. No limit at all.</li>
        <li>Any kind of porn/nudity is not allowed.</li>
        <li>You will be disqualified and banned if you try to manipulate our system.</li>
        <li>Your protected links must meet our terms of service.</li>
        <li> We reserve the right to modify the rewards program at any time without prior notice.</li>
        <li>we pay for all countries traffic.</li>
        <li>Minimum payout amount is $50.</li>
        <li>Payments are made through Paypal</li>
        <li>Payment done within 2 business days from payout request date. (It can take up to a week or 2 maximum)</li>
     </ul>
    
    <?php if(!$this->isLoggedIn): ?>
    <div class="row money-register">
        <em>What you waiting for? Start making money with links you share. easy & best</em>
        <div class="col-sm-3 col-sm-offset-1">
            <a href="/register" class="btn btn-primary btn-block">
                Register today
            </a>
        </div>
    </div>
  <?php endif; ?>
</div>
<?php $this->xinclude('partials/footer'); ?>