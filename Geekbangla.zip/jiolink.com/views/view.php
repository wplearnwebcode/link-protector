<?php $this->xinclude('partials/header'); ?>

<?php if($this->requestType == 'post'): ?>

<?php if($this->link_data->is_adsense): ?>

<?php endif; ?>
<br/>

<div class="alert alert-success view-success">
  <h1><i class="fa fa-unlock-alt" aria-hidden="true"></i>
  &nbsp;Links Unlocked Now. You can Download your files/video/music from "SAVE IT" button. </h1>
</div>

<div class="view-links">
Download Link Protector helps you offer downloads in a safe and secure way. You can still offer your downloads the way you have been doing till now. However now your downloads can not be copied or distributed through emails, forums and social networking websites.
    <div class="row">
        <h1 class="register-title"><?php echo ucwords($this->link_data->title); ?></h1>
        
<?php if($this->link_data->is_adsense): ?>

<br/>
</center>
<?php endif; ?>
        <div class="col-sm-8 col-sm-offset-2 well view-well">
            <?php

            $links = unserialize($this->link_data->content);

            foreach ($links as $k) {
              
              echo '<a href="'.$k.'" rel="nofollow" target="_blank">'.$k.'</a>';
            } 

            ?>
        </div>
    </div>
<?php if($this->link_data->is_adsense): ?>
<center></center>
<?php endif; ?>
</div>







<div class="view-options row">
    <div class="col-sm-3 view-option-box">
       <i class="label label-default">Created By</i>
       <?php $user = ($this->link_data->username)? $this->link_data->username : 'anonymouse'; ?>
       <em class="page-views"><?php echo ucwords($user); ?></em> 
    </div>
    <div class="col-sm-3 view-option-box">
       <i class="label label-default">Created On</i>
       <em class="page-views"><?php echo date('d M Y', strtotime($this->link_data->created)); ?></em> 
    </div>
    <div class="col-sm-3 view-option-box">
       <i class="label label-default">Views</i>
       <em class="page-views"><?php echo number_format($this->link_data->views); ?></em> 
    </div>
    <div class="col-sm-2 view-option-box view-options-save">
       <a href="/save/<?php echo $this->link_data->uid; ?>">
       <i class="fa fa-save" aria-hidden="true"></i>
       Save it</a>
    </div>
</div>
<br/>
<div class="view-options row">
    JioLink provides one of the finest Link Protecting services in the world. Our Team Experts have created our very own Link Sharing Algorithm (implemented carefully) to maintain your Links at Max Speed with the alternative of consuming much more and inappropriate Resources. We at JioLink always care for our users and protect their information and all the services are ascendable referred to your benefit like you can easily add more links and edit without putting a notable impact on yours mind.
    </div>

<?php else: ?>

<div class="alert view-warning">
  <h1> JioLink Download Your Links </h1>
  <h4>Your private link sharing partner </h4>
</div>

<?php if(System\Session::exists('error')): ?>
<div class="home-error-wrap">
  <div class="alert btn-danger">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo System\Session::flash('error'); ?>
  </div>
</div>
<?php endif; ?>

<div class="view-captcha">
<br>
  <p>JioLink provides one of the finest Link Protecting services in the world. Our Team Experts have created our very own Link Sharing Algorithm (implemented carefully) to maintain your Links at Max Speed with the alternative of consuming much more and inappropriate Resources. We at JioLink always care for our users and protect their information and all the services are ascendable referred to your benefit like you can easily add more links and edit without putting a notable impact on yours mind.</p>

<?php if($this->link_data->is_adsense): ?>    


</center>

<?php endif; ?>
<form method="post" action="">
<?php echo \Volnix\CSRF\CSRF::getHiddenInputString(); ?>

<?php if($this->isPassword): ?>
 <hr/>
  <div class="row">
    <div class="form-group">
        <label class="control-label col-sm-3" for="key">Enter Decrypt Key:</label>
        <div class="col-sm-6"> 
          <input type="password" name="password" class="form-control" id="key" placeholder="password here">
        </div>
    </div>
 </div>
<?php endif; ?>

<?php /*if(!$this->isLoggedIn): ?>
 <hr/>
 <div class="row captcha-box">
    <div class="col-sm-6 col-sm-offset-3 well"> 
        <div class="g-recaptcha" data-sitekey="<?php echo System\Config::google('key'); ?>"></div>
    </div>
 </div>
<?php endif; */ ?>

</div>

<div class="submit-captcha row">
    <div class="col-sm-3 col-sm-offset-4"> 
        <button type="submit" class="btn btn-primary btn-block">
            <i class="fa fa-lock" aria-hidden="true"></i>
            &nbsp;Unlock Links
        </button>
    </div>
</div>

</form>
<br/>
<div class="view-captcha">
<?php if($this->link_data->is_adsense): ?>    


<br/>
<p>Our system works very simply. Users can choose different settings like Google Captcha or can Encrypt with the password for protecting information from public. The easiest and most common way to protected links through our service is to go to our main page (home page), input your links in the text area (box) and press the "Protect your links" button. This will generate a results page where several outputs will be listed, such as generated protected links, direct links and remove links. go to 'Advanced Options' on (home page) to set your settings before submitting.</p>
<br/>
<p></p>Recently we launched these three step authentication technique. So that non authorized users are filtered and prevented from accessing your data. We understand that all these check takes time but we promise you�ll never face the down time which you did earlier. Now system is always healthy even under heavy load and queries. But still it is performing really well. We have started receiving positive feedback from our clients. We are happy now because you are satisfied with our services.You may also like about, Car Accident Lawyers, Auto Accident Attorney, Automobile Accident Attorney.</p>

<?php endif; ?>
</div>


<br/>
<div class="view-captcha">    
<center>
<p>JioLink Link Protector is a free link protection website to avoid any links from being indexed by spiders and eventually being listed on search engines. Download Here Movies Links, Amazon, Flipkart, Paytm, Hotstar, Voot, HD Music Movies Video Links Also can be added. Watch online music video films from many links shared by users.</p>
</center>

</div>
<?php endif; ?>

<?php $this->xinclude('partials/footer'); ?>