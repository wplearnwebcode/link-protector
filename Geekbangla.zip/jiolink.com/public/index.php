<?php

/**
 * Global named constants
 */
define('DS', DIRECTORY_SEPARATOR);
define('PATH', dirname(__FILE__).DS.'..'.DS);
define('EXT', '.php');

/**
 * Lets start the App now
 */
require PATH . 'start'.EXT;