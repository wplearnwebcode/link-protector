<?php

ini_set('session.gc_maxlifetime', 28800);

/**
 * Composer Autoload
 */
require PATH . 'vendor/autoload'.EXT;

/*
 * Set your applications current timezone
 */
date_default_timezone_set(System\Config::app('timezone'));

/*
 * Define the application error reporting level based on your environment
 */
if(System\Config::app('env') == 'dev'){
    ini_set('display_errors', true); error_reporting(-1);
}else{ 
    //error_reporting(0);
    
     ini_set('display_errors', true); error_reporting(-1);
}

/**
 * Starting Sessions
 */
System\Session::start();


/**
 * Including helper functions
 */
require PATH . 'functions/helpers' . EXT;

/**
 * Instanciate User
 */
$usero = new System\User();

/**
 * Intiate Databse Object (Singleton)
 */
$dbo = System\DB::getInstance();

/**
 * Route the request
 */
$router = new \AltoRouter();

/**
 * Import defined routes
 * check if admin there then import admin routes else just site routes
 */
require PATH . 'routes/site' . EXT;

if($usero->isAdmin()) 
    require PATH . 'routes/admin' . EXT;

/**
 * Matching the current request 
 */
$match = $router->match();

// if match matches
 if($match){

$params = $match['params'];
$target = $match['target'];

require  $target;

}else System\Response::error(404);
