<?php

/**
 * Encode html to entities
 */
function escapeText($str, $quotes = ENT_QUOTES) {
  return htmlspecialchars($str, $quotes, System\Config::app('encoding'), false);
}

/**
 * Debugging function, simply a var_dump wrapper
 * @example dd($something, $another);
 * @param mixed
 */
  function pp($data, $type = null) {
      echo '<pre>';
      if(!$type == null) var_dump($data);
      else print_r($data);
      echo '</pre>';
      exit;
  }

/**
 * match urls in the content
 * @return url
 */
function matchUrls($str){
    $pattern = '(?xi)\b((?:https?://|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’]))';
    
    if(!preg_match_all("#$pattern#i", $str, $urls))
        return false;

    return $urls[1];
}

/**
 * base64 encode without slashes
 * @param  string
 * @return string encoded
 */
function base64url_encode($s) {
    return str_replace(array('+', '/'), array('-', '_'), base64_encode($s));
}

function base64url_decode($s) {
    return base64_decode(str_replace(array('-', '_'), array('+', '/'), $s));
}

/**
 * 2 digits number places
 * @param  number
 * @return round
 */
function roundMoney($n){
  return number_format((float)$n, 4, '.', '');
}

/**
 * just a simple function to truncate text
 * @param string $string original string
 * @param integer $length length you need
 * @return string truncated string
 */
function limit_text($string, $length){
    return (strlen($string) > $length) ? substr($string,0,$length).'...' : $string;
}

/**
 * Something went url with redirect
 * @param  url $url
 * @return void
 */
function SomethingWrong($url, $message = null){

  if($message != null)
    System\Session::flash('error', $message);
  else
    System\Session::flash('error', 'Something went wrong! try again');
  
  System\Response::redirect($url);
}

function get_client_ip() {
    foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key){
        if (array_key_exists($key, $_SERVER) === true){
            foreach (explode(',', $_SERVER[$key]) as $ip){
                $ip = trim($ip); // just to be safe

                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false){
                    return $ip;
                }
            }
        }
    }
    
    return 'UNKNOWN';
}