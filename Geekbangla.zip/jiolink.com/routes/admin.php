<?php
use System\Module;

$router->map('GET|POST', '/admin/edit/[*:id]', Module::site('admin/edit') , 'admin-edit');
$router->map('GET|POST', '/admin/rates', Module::site('admin/rates') , 'admin-rates');
$router->map('GET|POST', '/admin/limit', Module::site('admin/limit') , 'admin-limit');