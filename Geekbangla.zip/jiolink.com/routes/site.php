<?php

use System\Module;

/** 
 * static pages
 */

$router->map('GET', '/', Module::site('home') , 'home');

$router->map('GET', '/save/[*:uid]', Module::site('save') , 'save');
$router->map('GET', '/faqs', Module::site('faqs') , 'faqs');
$router->map('GET', '/page/[*:slug]', Module::site('page') , 'page');
$router->map('GET', '/money', Module::site('money') , 'money');

$router->map('GET|POST', '/view/[*:uid]', Module::site('view') , 'view');
$router->map('GET|POST', '/contact', Module::site('contact') , 'contact');
$router->map('GET|POST', '/remove/[*:uid]', Module::site('remove') , 'remove');

$router->map('POST', '/protected', Module::site('protected') , 'protected');

// ajax action
$router->map( 'POST', '/action', Module::admin('action'), 'ajax-action');


if($usero->isLoggedIn()):

$router->map('GET', '/logout', Module::site('logout') , 'logout'); 
$router->map('GET|POST', '/user', Module::site('user') , 'user');
$router->map('GET|POST', '/payment/[*:user]?', Module::site('payment') , 'payment');

$router->map('GET|POST', '/manage/[*:type]/[*:page]?/[*:perpage]?/[*:sort]?', Module::site('manage') , 'manage');
$router->map('GET|POST', '/edit/[*:type]/[*:id]', Module::site('edit') , 'edit');

else:   

$router->map('GET|POST', '/login', Module::site('login') , 'login');
$router->map('GET|POST', '/register', Module::site('register') , 'register');

// forget password
$router->map('GET|POST', '/forget', Module::site('forget') , 'forget');
$router->map('GET|POST', '/reset/[*:hash]?', Module::site('reset') , 'reset');

/**
 * Social Logins
 */
$router->map( 'GET', '/loginwith/[*:type]', Module::site('loginwith'), 'loginwith');

endif;